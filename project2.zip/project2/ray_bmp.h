#ifndef RAY_BMP_H__
#define RAY_BMP_H__

#include "ray_render.h"

int render_bmp(struct framebuffer_pt4 *fb, const char *output_filepath);

#endif	// RAY_BMP_H__

