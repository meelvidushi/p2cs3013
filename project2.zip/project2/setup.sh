#!/bin/bash

sudo apt install -y flex bison libreadline-dev ffmpeg vlc

