#ifndef RAY_CONSOLE_H__
#define RAY_CONSOLE_H__

#include "ray_render.h"

void render_console(struct framebuffer_pt4 *fb);

#endif	// RAY_CONSOLE_H__

